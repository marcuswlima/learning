Maquina=""
SN=""
OL=""
function Erro
{
    Len=`expr length "$1"`
    C=`expr "(" 80 - "$Len" ")" / 2`
    tput cup 21 $C
    echo "$1\07\c"
    read a < /dev/tty
    tput cup 21 1
    echo "                                                                              "
    return
}

function Pergunta
{
    DefVal=`echo "$2" | tr "[a-z]" "[A-Z]"`
    OthVal=`echo "$3" | tr "[a-z]" "[A-Z]"`
    Quest=`echo "${1}"\? "${DefVal}"'//'`
    Len=`expr length "$Quest"`
    Col=`expr "(" 80 - "$Len" ")" / 2`
    tput cup 21 $Col
    echo "$Quest\07\c"
    read SN < /dev/tty
    
    SN=${SN:-"$DefVal"}

    SN=`echo $SN | tr "[a-z]" "[A-Z]"`
    if  [ "$SN" != "$OthVal" ]
    then
        SN="$DefVal"
    fi
    
    tput cup 21 1
    echo "                                                                              "
    return
}

Limpa ( )

{
    tput cup 21 1
    echo "                                                                              "
    return
}

Mostra ( )

{
    Mostra=$*
    Limpa 
    Len=`expr length "$Mostra"`
    Col=`expr "(" 80 - "$Len" ")" / 2`
    tput cup 21 $Col
    echo "$Mostra"
}


function Cab
{
clear
echo "
    +------------+------------+--------------------------------------------+
    |            |            |                                            |
    |  DATAPREV  |  TRANSFTP  |                     Producao RJ (821)2347  |
    |            |            |  Suporte (821)2338           SP (811)6200  |
    +------------+------------+--------------------------------------------+"
}

function Div    #  Faz divisao de inteiros dando resultado com $3 decimais
{
    Divid=$1
    Divis=$2
    Decim=$3
    Resp=`expr $Divid / $Divis`,
    while [ "$Decim" -gt 0 ]
    do
        Divid=`expr $Divid % $Divis \* 10`
        Resp=$Resp`expr $Divid / $Divis`
        Decim=`expr $Decim - 1`
    done
    return      #        Quociente editado esta em Resp
}

function ChecaPW
{
    Lin=$(($1\*4+7))

    if  [ "$2" -eq 1 ]
    then
        Site=RJ
        Maquina=durjcv01
    else
        Site=SP
        Maquina=duspmv01
    fi

    j=1            
    while true
    do
        tput cup $Lin $Cwr
        echo "Login Name em $Site ($LOGNAME):                          "
        tput cup $Lin $Cre
        read User
        User=${User:-"$LOGNAME"}
        tput cup $Lin $Cre
        echo $User
        tput cup $(($Lin+2)) $Cwr
        echo "Entre com Password em $Site:"
        tput cup $(($Lin+2)) $Cre
        stty -echo
        read PW
        stty echo
        if  [ ! "$PW" ]
        then
            Pergunta "Deseja continuar" S N
            if  [ "$SN" = N ]
            then
                exit
            fi    
            continue
        fi
        ftp -ivn $Maquina << fimftp > "/tmp/$$"     ##  So para testar a senha...
            user "$User" "$PW"
            quit
fimftp
        if  [ `grep -c "^530 " "/tmp/$$"` -ne 0 ]
        then
            j=`expr $j + 1`
            if  [ "$j" -eq 4 ]     ##  Se em 4 tentativas nao acertar; BYE BYE...
            then
                Erro "Tentativa de violacao. Programa descontinuado."
                rm /tmp/"$$"
                exit
            fi
            Erro "Senha nao confere. Tente outra vez."
            continue
        fi
        break
    done
}

function LeMaq
{
    Lin=$1
    Col=$2
    if  [ "$#" -eq 3 ]
    then
	MaqDef=$3
    fi
    while true
    do
        tput cup $Lin $Col
        echo "                                                                              "
        tput cup $Lin $Col
        read Maquina
        if  [ "$#" -eq 3 ]
	then
            Maquina=${Maquina:-"$MaqDef"}
        fi
        if  [ ! "$Maquina" ]
        then
            SN "Deseja Abandonar" S N
            if  [ "$SN" = N ]
            then
                continue
            fi
            exit
        fi
		
        if  [ `fgrep -c "$Maquina" /etc/hosts` -eq 0 ]
        then
            Erro "Nao existe regional com maquina com este nome"
            continue
        fi
        return
    done
}

function LeOL
{
    Col=$1
    Lin=$2
    OLs="02 03 04 05 06 07 08 09 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 26 28"
    while true
    do
        tput cup $Lin $Col
        echo "                                                                              "
        tput cup $Lin $Col
        read OL
        if  [ ! "$OL" ]
        then
            SN "Deseja Abandonar" S N
	    if  [ "$SN" = N ]
	    then
                continue
            fi
            exit
        fi
		
        if  [ `echo "$Maquina" | fgrep -c "$OLs"` -eq 0 ]
	then
            Erro "Nao existe OL com este numero"
            continue
        fi
        return
    done
}
